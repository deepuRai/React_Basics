import React, { Component } from 'react';

//Creating loading component
const Loading = ({message}) => <h2>{message}</h2>

export default Loading;